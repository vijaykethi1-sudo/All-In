import { useEffect, useState } from 'react';
import { Activity, Code2, GraduationCap, Layers3, PlayCircle, type LucideIcon } from 'lucide-react';
import { api } from './lib/api';
import type { GameState } from './types';
import { Coach } from './components/Coach';
import { Learn } from './components/Learn';
import { MetricCard } from './components/MetricCard';
import { Simulator } from './components/Simulator';
import './styles.css';

type Tab = 'overview' | 'simulator' | 'learn';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [apiStatus, setApiStatus] = useState<'checking' | 'online' | 'offline'>('checking');
  const [currentGame, setCurrentGame] = useState<GameState | null>(null);
  useEffect(() => { api.health().then(() => setApiStatus('online')).catch(() => setApiStatus('offline')); }, []);
  const tabs: Array<{ id: Tab; label: string; Icon: LucideIcon }> = [
    { id: 'overview', label: 'Overview', Icon: Layers3 },
    { id: 'simulator', label: 'Simulator', Icon: PlayCircle },
    { id: 'learn', label: 'Learn', Icon: GraduationCap },
  ];
  return (
    <div className="app-shell">
      <header className="hero">
        <nav className="top-nav"><div className="brand-mark">AI</div><div><strong>All-In Academy</strong><span>Texas Hold&apos;em Training Lab</span></div><div className={`status status--${apiStatus}`}><Activity size={15} /> API {apiStatus}</div></nav>
        <div className="hero-content"><span className="eyebrow">Full-stack portfolio project</span><h1>Practice poker decisions with a live simulator and coaching API.</h1><p>A professional rebuild of the poker trainer with a React front end, FastAPI backend, hand evaluation engine, coaching endpoint, and deployable repository structure.</p><div className="hero-actions"><button className="button button--primary" onClick={() => setActiveTab('simulator')}><PlayCircle size={18} /> Launch Simulator</button><button className="button button--secondary" onClick={() => setActiveTab('learn')}><GraduationCap size={18} /> Study Concepts</button></div></div>
      </header>
      <main className="workspace"><section className="main-column"><div className="tabs">{tabs.map(({ id, label, Icon }) => <button key={id} className={activeTab === id ? 'active' : ''} onClick={() => setActiveTab(id)}><Icon size={16} /> {label}</button>)}</div>{activeTab === 'overview' ? <Overview /> : null}{activeTab === 'simulator' ? <Simulator onGameChange={setCurrentGame} /> : null}{activeTab === 'learn' ? <Learn /> : null}</section><Coach game={currentGame} /></main>
    </div>
  );
}

function Overview() {
  return (
    <section className="overview-grid">
      <MetricCard label="Frontend" value="React + TypeScript" note="Vite development workflow" />
      <MetricCard label="Backend" value="FastAPI" note="REST endpoints + validation" />
      <MetricCard label="Engine" value="Poker evaluator" note="7-card hand comparison" />
      <MetricCard label="Coach" value="API driven" note="Rule-based coaching endpoint" />
      <article className="panel panel--wide"><span className="eyebrow"><Code2 size={14} /> Why this is more company-ready</span><h2>It demonstrates product thinking and engineering structure.</h2><p>The original single-file app proved creativity and front-end fundamentals. This version adds a real API layer, typed front-end models, reusable React components, server-side poker logic, API documentation, and a README with local run instructions.</p></article>
      <article className="panel"><span className="eyebrow">Architecture</span><h2>Separation of concerns</h2><p>UI, API calls, game logic, schemas, and coaching rules live in separate files so reviewers can understand the codebase quickly.</p></article>
      <article className="panel"><span className="eyebrow">Portfolio angle</span><h2>Clear talking points</h2><p>Use this to discuss React state, API design, CORS, Pydantic validation, algorithmic hand evaluation, and deployment strategy.</p></article>
    </section>
  );
}
