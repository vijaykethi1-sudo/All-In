export type Stage = 'PREFLOP' | 'FLOP' | 'TURN' | 'RIVER' | 'SHOWDOWN' | 'COMPLETE';
export type ActionKind = 'check_call' | 'bet' | 'fold' | 'new_hand';

export interface Card {
  rank: string;
  suit: string;
  value: number;
  color: 'red' | 'black';
  label: string;
}

export interface Player {
  name: string;
  chips: number;
  holeCards: Card[];
  committed: number;
  folded: boolean;
}

export interface Evaluation {
  category: number;
  name: string;
  tiebreakers: number[];
  cards: Card[];
}

export interface LegalAction {
  kind: ActionKind;
  label: string;
  amount?: number;
}

export interface GameState {
  gameId: string;
  stage: Stage;
  communityCards: Card[];
  player: Player;
  opponent: Player;
  opponentCardBacks: number;
  pot: number;
  toCall: number;
  minBet: number;
  dealer: string;
  handNumber: number;
  winner: string | null;
  result: string | null;
  playerBest: Evaluation | null;
  opponentBest: Evaluation | null;
  log: string[];
  legalActions: LegalAction[];
  coachHint: string;
}

export interface CoachMessage {
  role: 'user' | 'coach';
  content: string;
}
