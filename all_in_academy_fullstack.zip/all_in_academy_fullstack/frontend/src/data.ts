export const handRankings = [
  { rank: 1, name: 'Royal Flush', description: 'A-K-Q-J-10 all in the same suit. The top possible hand.' },
  { rank: 2, name: 'Straight Flush', description: 'Five consecutive cards in the same suit.' },
  { rank: 3, name: 'Four of a Kind', description: 'Four cards of the same rank.' },
  { rank: 4, name: 'Full House', description: 'Three of a kind plus a pair.' },
  { rank: 5, name: 'Flush', description: 'Five cards of the same suit, not consecutive.' },
  { rank: 6, name: 'Straight', description: 'Five consecutive cards with mixed suits.' },
  { rank: 7, name: 'Three of a Kind', description: 'Three cards of the same rank.' },
  { rank: 8, name: 'Two Pair', description: 'Two different pairs.' },
  { rank: 9, name: 'One Pair', description: 'Two cards of the same rank.' },
  { rank: 10, name: 'High Card', description: 'No made combination; highest card plays.' },
];

export const concepts = [
  { title: 'Position', copy: 'Acting later gives you more information. Button and cutoff seats can play wider ranges than early position.' },
  { title: 'Pot Odds', copy: 'Compare the call price to the total pot. If your equity beats the required percentage, the call can be profitable.' },
  { title: 'Value Betting', copy: 'Bet strong hands when worse hands can call. Value betting is where long-term profit comes from.' },
  { title: 'Bluff Discipline', copy: 'Bluff when your story makes sense, your range has strong hands, and the opponent can fold.' },
];
