import { useState } from 'react';
import { Send } from 'lucide-react';
import { api } from '../lib/api';
import type { CoachMessage, GameState } from '../types';

interface CoachProps { game: GameState | null; }

export function Coach({ game }: CoachProps) {
  const [messages, setMessages] = useState<CoachMessage[]>([{ role: 'coach', content: 'Welcome to All-In Academy. Ask about starting hands, pot odds, position, bluffing, or what to do in the simulator.' }]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(prompt?: string) {
    const text = (prompt ?? input).trim();
    if (!text || loading) return;
    setInput(''); setMessages((current) => [...current, { role: 'user', content: text }]); setLoading(true);
    try { const response = await api.askCoach(text, game?.gameId); setMessages((current) => [...current, { role: 'coach', content: response.reply }]); }
    catch { setMessages((current) => [...current, { role: 'coach', content: 'The coaching API is offline. Start the FastAPI backend, then try again.' }]); }
    finally { setLoading(false); }
  }
  const quickPrompts = ['What should I do?', 'Explain pot odds', 'When should I bluff?', 'Best starting hands?'];
  return (
    <aside className="coach-panel">
      <div className="panel-header"><div className="avatar">A</div><div><span className="eyebrow">API Coach</span><h2>Ace Coach</h2></div></div>
      <div className="coach-messages">{messages.map((message, index) => <div key={`${message.role}-${index}`} className={`coach-message coach-message--${message.role}`}>{message.content.split('\n').map((line) => <p key={line}>{line}</p>)}</div>)}</div>
      <div className="quick-prompts">{quickPrompts.map((prompt) => <button key={prompt} onClick={() => submit(prompt)} disabled={loading}>{prompt}</button>)}</div>
      <form className="coach-form" onSubmit={(event) => { event.preventDefault(); void submit(); }}><input value={input} onChange={(event) => setInput(event.target.value)} placeholder="Ask the poker coach..." /><button className="button button--primary" disabled={!input.trim() || loading} type="submit"><Send size={16} /></button></form>
    </aside>
  );
}
