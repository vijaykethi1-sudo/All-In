import type { Card } from '../types';

interface CardViewProps { card?: Card; hidden?: boolean; compact?: boolean; }

export function CardView({ card, hidden = false, compact = false }: CardViewProps) {
  if (hidden || !card) return <div className={`card card--back ${compact ? 'card--compact' : ''}`} aria-label="Hidden card" />;
  return (
    <div className={`card card--${card.color} ${compact ? 'card--compact' : ''}`} aria-label={card.label}>
      <span className="card__corner">{card.rank}</span>
      <strong className="card__rank">{card.rank}</strong>
      <span className="card__suit">{card.suit}</span>
    </div>
  );
}
