import { concepts, handRankings } from '../data';

export function Learn() {
  return (
    <section className="learn-grid">
      <div className="panel"><span className="eyebrow">Reference</span><h2>Hand Rankings</h2><div className="ranking-list">{handRankings.map((hand) => <article key={hand.name}><span>#{hand.rank}</span><div><h3>{hand.name}</h3><p>{hand.description}</p></div></article>)}</div></div>
      <div className="panel"><span className="eyebrow">Strategy</span><h2>Core Concepts</h2><div className="concept-grid">{concepts.map((concept) => <article key={concept.title}><h3>{concept.title}</h3><p>{concept.copy}</p></article>)}</div></div>
    </section>
  );
}
