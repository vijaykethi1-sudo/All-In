interface MetricCardProps { label: string; value: string; note?: string; }

export function MetricCard({ label, value, note }: MetricCardProps) {
  return <article className="metric-card"><span>{label}</span><strong>{value}</strong>{note ? <small>{note}</small> : null}</article>;
}
