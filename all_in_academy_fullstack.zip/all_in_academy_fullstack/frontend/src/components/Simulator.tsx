import { useEffect, useMemo, useState } from 'react';
import { Bot, Brain, RefreshCcw, ShieldAlert, Sparkles } from 'lucide-react';
import { api } from '../lib/api';
import type { Card, GameState } from '../types';
import { CardView } from './CardView';
import { MetricCard } from './MetricCard';

interface SimulatorProps { onGameChange?: (game: GameState | null) => void; }

export function Simulator({ onGameChange }: SimulatorProps) {
  const [game, setGame] = useState<GameState | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function commitGame(nextGame: GameState | null) { setGame(nextGame); onGameChange?.(nextGame); }

  const communitySlots = useMemo(() => {
    const slots: Array<Card | undefined> = [...(game?.communityCards ?? [])];
    while (slots.length < 5) slots.push(undefined);
    return slots;
  }, [game]);

  async function startGame() {
    setLoading(true); setError(null);
    try { commitGame(await api.createGame()); }
    catch (err) { setError(err instanceof Error ? err.message : 'Unable to start game'); }
    finally { setLoading(false); }
  }

  async function takeAction(kind: string, amount = 0) {
    if (!game) return;
    if (kind === 'new_hand') { await startGame(); return; }
    setLoading(true); setError(null);
    try { commitGame(await api.takeAction(game.gameId, kind, amount)); }
    catch (err) { setError(err instanceof Error ? err.message : 'Action failed'); }
    finally { setLoading(false); }
  }

  useEffect(() => { void startGame(); }, []);

  if (error) {
    return <section className="panel simulator-error"><ShieldAlert /><h2>Backend connection needed</h2><p>{error}</p><p>Start the FastAPI server on port 8000, then reload the React app.</p><button className="button button--primary" onClick={startGame}>Retry</button></section>;
  }

  return (
    <section className="simulator-grid">
      <div className="table-shell"><div className="table-felt">
        <div className="table-row table-row--top"><div><span className="eyebrow">Opponent</span><h3>{game?.opponent.name ?? 'Table Pro'}</h3></div><div className="hand-row">{game?.opponent.holeCards.length ? game.opponent.holeCards.map((card) => <CardView key={card.label} card={card} />) : Array.from({ length: game?.opponentCardBacks ?? 2 }).map((_, index) => <CardView key={index} hidden />)}</div><strong>{game?.opponent.chips ?? '—'} chips</strong></div>
        <div className="community-zone"><span className="table-label">Community Cards</span><div className="community-row">{communitySlots.map((card, index) => <CardView key={card?.label ?? index} card={card} hidden={!card} />)}</div><div className="pot-pill">Pot: {game?.pot ?? 0}</div></div>
        <div className="table-row table-row--bottom"><div><span className="eyebrow">Player</span><h3>Your Hand</h3></div><div className="hand-row">{game?.player.holeCards.map((card) => <CardView key={card.label} card={card} />)}</div><strong>{game?.player.chips ?? '—'} chips</strong></div>
      </div></div>
      <aside className="decision-panel">
        <div className="panel-header"><Sparkles /><div><span className="eyebrow">Current Street</span><h2>{game?.stage ?? 'Loading'}</h2></div></div>
        <div className="metrics-row"><MetricCard label="To Call" value={`${game?.toCall ?? 0}`} /><MetricCard label="Minimum Bet" value={`${game?.minBet ?? 0}`} /></div>
        <div className="coach-hint"><Brain /><p>{game?.coachHint ?? 'Starting simulator...'}</p></div>
        <div className="actions-grid">{game?.legalActions.map((action) => <button key={`${action.kind}-${action.amount ?? 0}`} className={`button ${action.kind === 'fold' ? 'button--ghost' : 'button--primary'}`} disabled={loading} onClick={() => takeAction(action.kind, action.amount)}>{action.kind === 'new_hand' ? <RefreshCcw size={16} /> : null}{action.label}</button>)}</div>
        {game?.result ? <div className="result-box"><Bot /> {game.result}</div> : null}
        <div className="hand-log"><span className="eyebrow">Hand Log</span><ul>{(game?.log ?? []).slice(-7).map((entry, index) => <li key={`${entry}-${index}`}>{entry}</li>)}</ul></div>
      </aside>
    </section>
  );
}
