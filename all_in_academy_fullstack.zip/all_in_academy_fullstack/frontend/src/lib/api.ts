import type { GameState } from '../types';

const API_BASE = import.meta.env.VITE_API_URL ?? 'http://localhost:8000';

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers ?? {}) },
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `Request failed with status ${response.status}`);
  }
  return response.json() as Promise<T>;
}

export const api = {
  health: () => request<{ status: string; service: string }>('/api/health'),
  createGame: () => request<GameState>('/api/games', { method: 'POST' }),
  getGame: (gameId: string) => request<GameState>(`/api/games/${gameId}`),
  takeAction: (gameId: string, kind: string, amount = 0) => request<GameState>(`/api/games/${gameId}/actions`, { method: 'POST', body: JSON.stringify({ kind, amount }) }),
  askCoach: (message: string, gameId?: string) => request<{ reply: string; suggested_action: string | null }>('/api/coach', { method: 'POST', body: JSON.stringify({ message, game_id: gameId }) }),
};
