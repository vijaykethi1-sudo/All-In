from app.poker_engine import Card, apply_action, evaluate_best, make_game


def test_royal_flush_beats_full_house():
    royal = [Card("A", "♠"), Card("K", "♠"), Card("Q", "♠"), Card("J", "♠"), Card("10", "♠"), Card("2", "♦"), Card("3", "♣")]
    full_house = [Card("A", "♠"), Card("A", "♦"), Card("A", "♣"), Card("K", "♠"), Card("K", "♦"), Card("2", "♣"), Card("3", "♣")]
    assert evaluate_best(royal).sort_key() > evaluate_best(full_house).sort_key()


def test_wheel_straight_is_detected():
    cards = [Card("A", "♠"), Card("2", "♦"), Card("3", "♣"), Card("4", "♥"), Card("5", "♠"), Card("9", "♦"), Card("K", "♣")]
    assert evaluate_best(cards).name == "Straight"


def test_game_advances_from_preflop_to_flop():
    game = make_game("test", seed=7)
    updated = apply_action(game, "check_call")
    assert updated.stage == "FLOP"
    assert len(updated.community_cards) == 3
