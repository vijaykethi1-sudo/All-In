from __future__ import annotations

from uuid import uuid4
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .coach import coach_reply
from .poker_engine import GameState, apply_action, make_game
from .schemas import ActionRequest, CoachRequest, CoachResponse

app = FastAPI(
    title="All-In Academy API",
    description="A portfolio-ready poker training API with a Texas Hold'em simulator and coaching endpoints.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

GAMES: dict[str, GameState] = {}


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "service": "all-in-academy-api"}


@app.post("/api/games")
def create_game() -> dict:
    game_id = str(uuid4())
    game = make_game(game_id)
    GAMES[game_id] = game
    return game.to_dict()


@app.get("/api/games/{game_id}")
def get_game(game_id: str) -> dict:
    game = GAMES.get(game_id)
    if not game:
        raise HTTPException(status_code=404, detail="Game not found")
    return game.to_dict()


@app.post("/api/games/{game_id}/actions")
def game_action(game_id: str, payload: ActionRequest) -> dict:
    game = GAMES.get(game_id)
    if not game:
        raise HTTPException(status_code=404, detail="Game not found")
    updated = apply_action(game, payload.kind, payload.amount)
    GAMES[game_id] = updated
    return updated.to_dict()


@app.post("/api/coach", response_model=CoachResponse)
def coach(payload: CoachRequest) -> CoachResponse:
    game = GAMES.get(payload.game_id) if payload.game_id else None
    reply, suggested_action = coach_reply(payload.message, game)
    return CoachResponse(reply=reply, suggested_action=suggested_action)
