from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field


class ActionRequest(BaseModel):
    kind: Literal["check_call", "bet", "fold"]
    amount: int = Field(default=0, ge=0, le=10000)


class CoachRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1000)
    game_id: str | None = None


class CoachResponse(BaseModel):
    reply: str
    suggested_action: str | None = None
