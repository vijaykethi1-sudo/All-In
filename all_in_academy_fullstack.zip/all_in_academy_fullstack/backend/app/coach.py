from __future__ import annotations

from .poker_engine import GameState, current_strength, describe_hole_cards, evaluate_best


def coach_reply(message: str, game: GameState | None = None) -> tuple[str, str | None]:
    text = message.lower().strip()
    if game:
        suggestion = suggest_action(game)
        state_line = describe_game(game)
        if any(term in text for term in ["what should", "what do", "action", "move", "play", "advice"]):
            return f"{state_line}\n\nRecommended action: {suggestion}. Keep your sizing consistent and avoid betting just because you are bored.", suggestion
    if "pot odds" in text or "odds" in text:
        return ("Pot odds compare the price of a call to the pot you can win. If the pot is 100 and the call is 25, you are calling 25 to win 125, so you need about 20% equity. Draws become profitable when your chance to hit is higher than the required equity.", None)
    if "bluff" in text:
        return ("A good bluff tells a believable story. Bluff more when you have blockers, position, and fold equity. Do not bluff players who hate folding. That is not courage; that is donating chips.", None)
    if "position" in text or "button" in text:
        return ("Position is information advantage. Acting last lets you see checks, bets, and sizing before committing chips. The button is the most profitable seat because your decisions use the most data.", None)
    if "starting" in text or "preflop" in text or "hands" in text:
        return ("Strong starting hands include premium pairs, A-K, A-Q suited, and broadway suited hands. Small pairs and suited connectors improve in late position. Weak offsuit hands should usually go straight into the muck.", None)
    if "bankroll" in text:
        return ("Bankroll management keeps variance from knocking you out. Play stakes where one losing session does not matter. Good players still lose hands; disciplined players survive the swings.", None)
    return ("Ask me about starting hands, position, pot odds, bluffing, or what to do in the current simulator hand. I will keep the answer direct and actionable.", None)


def describe_game(game: GameState) -> str:
    if game.stage in {"SHOWDOWN", "COMPLETE"}:
        return game.result or "The hand is over."
    if len(game.community_cards) >= 3:
        evaluation = evaluate_best(game.player.hole_cards + game.community_cards)
        return f"Stage: {game.stage}. Pot: {game.pot}. Your current hand is {evaluation.name}."
    return f"Stage: {game.stage}. Pot: {game.pot}. Your hole cards are a {describe_hole_cards(game.player.hole_cards)}."


def suggest_action(game: GameState) -> str:
    if game.stage in {"SHOWDOWN", "COMPLETE"}:
        return "New Hand"
    strength = current_strength(game, game.player)
    if game.to_call and strength < 0.32:
        return "Fold"
    if strength >= 0.68:
        return "Bet 100"
    if strength >= 0.48:
        return "Bet 50" if game.to_call == 0 else "Call"
    return "Check" if game.to_call == 0 else "Call small / fold large"
