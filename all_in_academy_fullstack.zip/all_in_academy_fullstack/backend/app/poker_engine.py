from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from random import Random
from typing import Iterable, Literal

SUITS = ["♠", "♥", "♦", "♣"]
RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
VALUES = {rank: index + 2 for index, rank in enumerate(RANKS)}
DISPLAY_RANK = {"10": "T", "J": "J", "Q": "Q", "K": "K", "A": "A"}

Stage = Literal["PREFLOP", "FLOP", "TURN", "RIVER", "SHOWDOWN", "COMPLETE"]
ActionKind = Literal["check_call", "bet", "fold", "new_hand"]


@dataclass(frozen=True)
class Card:
    rank: str
    suit: str

    @property
    def value(self) -> int:
        return VALUES[self.rank]

    @property
    def color(self) -> str:
        return "red" if self.suit in {"♥", "♦"} else "black"

    def label(self) -> str:
        return f"{DISPLAY_RANK.get(self.rank, self.rank)}{self.suit}"

    def to_dict(self) -> dict:
        return {"rank": self.rank, "suit": self.suit, "value": self.value, "color": self.color, "label": self.label()}


@dataclass(frozen=True)
class Evaluation:
    category: int
    tiebreakers: tuple[int, ...]
    name: str
    cards: tuple[Card, ...]

    def sort_key(self) -> tuple[int, tuple[int, ...]]:
        return self.category, self.tiebreakers

    def to_dict(self) -> dict:
        return {
            "category": self.category,
            "name": self.name,
            "tiebreakers": list(self.tiebreakers),
            "cards": [card.to_dict() for card in self.cards],
        }


@dataclass
class PlayerState:
    name: str
    chips: int
    hole_cards: list[Card]
    committed: int = 0
    folded: bool = False

    def to_public_dict(self, reveal_cards: bool = True) -> dict:
        return {
            "name": self.name,
            "chips": self.chips,
            "holeCards": [card.to_dict() for card in self.hole_cards] if reveal_cards else [],
            "committed": self.committed,
            "folded": self.folded,
        }


@dataclass
class GameState:
    game_id: str
    stage: Stage
    deck: list[Card]
    community_cards: list[Card]
    player: PlayerState
    opponent: PlayerState
    pot: int
    to_call: int
    min_bet: int
    dealer: str
    hand_number: int
    winner: str | None = None
    result: str | None = None
    player_best: Evaluation | None = None
    opponent_best: Evaluation | None = None
    log: list[str] | None = None

    def to_dict(self, reveal_opponent: bool | None = None) -> dict:
        reveal = reveal_opponent if reveal_opponent is not None else self.stage in {"SHOWDOWN", "COMPLETE"}
        return {
            "gameId": self.game_id,
            "stage": self.stage,
            "communityCards": [card.to_dict() for card in self.community_cards],
            "player": self.player.to_public_dict(reveal_cards=True),
            "opponent": self.opponent.to_public_dict(reveal_cards=reveal),
            "opponentCardBacks": 0 if reveal else len(self.opponent.hole_cards),
            "pot": self.pot,
            "toCall": self.to_call,
            "minBet": self.min_bet,
            "dealer": self.dealer,
            "handNumber": self.hand_number,
            "winner": self.winner,
            "result": self.result,
            "playerBest": self.player_best.to_dict() if self.player_best else None,
            "opponentBest": self.opponent_best.to_dict() if self.opponent_best else None,
            "log": self.log or [],
            "legalActions": legal_actions(self),
            "coachHint": coach_hint_for_state(self),
        }


def fresh_deck(seed: int | None = None) -> list[Card]:
    rng = Random(seed)
    deck = [Card(rank, suit) for suit in SUITS for rank in RANKS]
    rng.shuffle(deck)
    return deck


def make_game(game_id: str, seed: int | None = None, hand_number: int = 1) -> GameState:
    deck = fresh_deck(seed)
    player_cards = [deck.pop(), deck.pop()]
    opponent_cards = [deck.pop(), deck.pop()]
    player = PlayerState("You", chips=990, hole_cards=player_cards, committed=10)
    opponent = PlayerState("Table Pro", chips=980, hole_cards=opponent_cards, committed=20)
    return GameState(
        game_id=game_id,
        stage="PREFLOP",
        deck=deck,
        community_cards=[],
        player=player,
        opponent=opponent,
        pot=30,
        to_call=10,
        min_bet=20,
        dealer="You",
        hand_number=hand_number,
        log=["New hand started. You posted the small blind. Table Pro posted the big blind."],
    )


def legal_actions(game: GameState) -> list[dict]:
    if game.stage in {"SHOWDOWN", "COMPLETE"}:
        return [{"kind": "new_hand", "label": "New Hand"}]
    call_label = "Call" if game.to_call > 0 else "Check"
    actions = [{"kind": "check_call", "label": f"{call_label} {game.to_call}" if game.to_call else call_label}]
    for amount in [25, 50, 100]:
        max_affordable = min(game.player.chips, game.opponent.chips)
        if amount <= max_affordable:
            actions.append({"kind": "bet", "label": f"Bet {amount}", "amount": amount})
    actions.append({"kind": "fold", "label": "Fold"})
    return actions


def straight_high(values: Iterable[int]) -> int | None:
    unique = sorted(set(values), reverse=True)
    if 14 in unique:
        unique.append(1)
    for i in range(max(0, len(unique) - 4)):
        window = unique[i : i + 5]
        if len(window) == 5 and window[0] - window[4] == 4:
            return 14 if window[0] == 14 else window[0]
    return None


def evaluate_five(cards: Iterable[Card]) -> Evaluation:
    five = tuple(cards)
    values = sorted([card.value for card in five], reverse=True)
    counts: dict[int, int] = {}
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    grouped = sorted(counts.items(), key=lambda item: (item[1], item[0]), reverse=True)
    is_flush = len({card.suit for card in five}) == 1
    s_high = straight_high(values)

    if is_flush and s_high:
        return Evaluation(9, (14,), "Royal Flush", five) if s_high == 14 else Evaluation(8, (s_high,), "Straight Flush", five)
    if grouped[0][1] == 4:
        quad = grouped[0][0]
        kicker = max(value for value in values if value != quad)
        return Evaluation(7, (quad, kicker), "Four of a Kind", five)
    if grouped[0][1] == 3 and grouped[1][1] == 2:
        return Evaluation(6, (grouped[0][0], grouped[1][0]), "Full House", five)
    if is_flush:
        return Evaluation(5, tuple(values), "Flush", five)
    if s_high:
        return Evaluation(4, (s_high,), "Straight", five)
    if grouped[0][1] == 3:
        trips = grouped[0][0]
        kickers = tuple(value for value in values if value != trips)[:2]
        return Evaluation(3, (trips, *kickers), "Three of a Kind", five)
    if grouped[0][1] == 2 and grouped[1][1] == 2:
        pair_values = sorted([value for value, count in counts.items() if count == 2], reverse=True)
        kicker = max(value for value in values if value not in pair_values)
        return Evaluation(2, (*pair_values[:2], kicker), "Two Pair", five)
    if grouped[0][1] == 2:
        pair = grouped[0][0]
        kickers = tuple(value for value in values if value != pair)[:3]
        return Evaluation(1, (pair, *kickers), "One Pair", five)
    return Evaluation(0, tuple(values), "High Card", five)


def evaluate_best(cards: Iterable[Card]) -> Evaluation:
    card_list = list(cards)
    if len(card_list) < 5:
        raise ValueError("At least five cards are required to evaluate a complete poker hand.")
    return max((evaluate_five(combo) for combo in combinations(card_list, 5)), key=lambda ev: ev.sort_key())


def describe_hole_cards(cards: list[Card]) -> str:
    first, second = cards
    suited = first.suit == second.suit
    pair = first.rank == second.rank
    values = sorted([first.value, second.value], reverse=True)
    if pair:
        if values[0] >= 11:
            return "premium pocket pair"
        if values[0] >= 8:
            return "solid pocket pair"
        return "small pocket pair"
    if values[0] == 14 and values[1] >= 11:
        return "premium ace-high Broadway hand"
    if values[0] >= 12 and values[1] >= 10:
        return "playable Broadway hand"
    if suited and abs(values[0] - values[1]) <= 1:
        return "suited connector"
    if suited:
        return "suited speculative hand"
    return "marginal starting hand"


def preflop_score(cards: list[Card]) -> float:
    a, b = sorted([card.value for card in cards], reverse=True)
    suited = cards[0].suit == cards[1].suit
    pair = a == b
    score = a / 14
    if pair:
        score += 0.48 + (a / 100)
    if suited:
        score += 0.08
    gap = a - b
    if gap == 1:
        score += 0.08
    elif gap == 2:
        score += 0.04
    elif gap >= 5:
        score -= 0.12
    if a == 14 and b >= 10:
        score += 0.12
    return max(0.05, min(score, 1.0))


def current_strength(game: GameState, player: PlayerState) -> float:
    cards = player.hole_cards + game.community_cards
    if len(cards) >= 5:
        ev = evaluate_best(cards)
        base = ev.category / 9
        kicker_bonus = sum(ev.tiebreakers[:2]) / 100
        return min(1.0, base + kicker_bonus)
    return preflop_score(player.hole_cards)


def opponent_decision(game: GameState, faced_bet: int) -> str:
    strength = current_strength(game, game.opponent)
    pot_odds_pressure = faced_bet / max(1, game.pot + faced_bet)
    if strength >= 0.62:
        return "call"
    if strength >= 0.42 and pot_odds_pressure <= 0.36:
        return "call"
    if strength >= 0.32 and faced_bet <= game.min_bet:
        return "call"
    return "fold"


def contribute(player: PlayerState, amount: int) -> int:
    paid = min(max(0, amount), player.chips)
    player.chips -= paid
    player.committed += paid
    return paid


def advance_street(game: GameState) -> None:
    game.to_call = 0
    game.player.committed = 0
    game.opponent.committed = 0
    if game.stage == "PREFLOP":
        game.community_cards.extend([game.deck.pop(), game.deck.pop(), game.deck.pop()])
        game.stage = "FLOP"
        game.log.append("Flop dealt. Three community cards are now live.")
    elif game.stage == "FLOP":
        game.community_cards.append(game.deck.pop())
        game.stage = "TURN"
        game.log.append("Turn dealt. One card to come.")
    elif game.stage == "TURN":
        game.community_cards.append(game.deck.pop())
        game.stage = "RIVER"
        game.log.append("River dealt. Final betting decision.")
    elif game.stage == "RIVER":
        showdown(game)


def showdown(game: GameState) -> None:
    game.stage = "SHOWDOWN"
    game.player_best = evaluate_best(game.player.hole_cards + game.community_cards)
    game.opponent_best = evaluate_best(game.opponent.hole_cards + game.community_cards)
    if game.player_best.sort_key() > game.opponent_best.sort_key():
        game.winner = "player"
        game.player.chips += game.pot
        game.result = f"You win {game.pot} with {game.player_best.name}."
    elif game.opponent_best.sort_key() > game.player_best.sort_key():
        game.winner = "opponent"
        game.opponent.chips += game.pot
        game.result = f"Table Pro wins {game.pot} with {game.opponent_best.name}."
    else:
        game.winner = "split"
        game.player.chips += game.pot // 2
        game.opponent.chips += game.pot - (game.pot // 2)
        game.result = f"Split pot. Both players show {game.player_best.name}."
    game.log.append(game.result)


def apply_action(game: GameState, action: ActionKind, amount: int = 0) -> GameState:
    if game.stage in {"SHOWDOWN", "COMPLETE"}:
        game.log.append("Hand is complete. Start a new hand to continue.")
        return game
    if action == "fold":
        game.player.folded = True
        game.winner = "opponent"
        game.opponent.chips += game.pot
        game.result = f"You folded. Table Pro wins the {game.pot} chip pot."
        game.stage = "COMPLETE"
        game.log.append(game.result)
        return game
    if action == "check_call":
        paid = contribute(game.player, game.to_call)
        game.pot += paid
        game.log.append(f"You called {paid}." if paid else "You checked.")
        game.log.append("Table Pro checks behind.")
        advance_street(game)
        return game
    if action == "bet":
        wager = max(game.min_bet, amount or game.min_bet)
        call_paid = contribute(game.player, game.to_call)
        bet_paid = contribute(game.player, wager)
        total_faced = call_paid + bet_paid
        game.pot += total_faced
        game.log.append(f"You put {total_faced} chips in the middle.")
        if opponent_decision(game, total_faced) == "fold":
            game.opponent.folded = True
            game.winner = "player"
            game.player.chips += game.pot
            game.result = f"Table Pro folded. You win the {game.pot} chip pot."
            game.stage = "COMPLETE"
            game.log.append(game.result)
            return game
        called = contribute(game.opponent, total_faced)
        game.pot += called
        game.log.append(f"Table Pro called {called}.")
        advance_street(game)
        return game
    game.log.append("Unknown action ignored.")
    return game


def coach_hint_for_state(game: GameState) -> str:
    if game.stage in {"SHOWDOWN", "COMPLETE"}:
        return game.result or "Start a new hand to keep practicing."
    if len(game.community_cards) >= 3:
        evaluation = evaluate_best(game.player.hole_cards + game.community_cards)
        if evaluation.category >= 4:
            return f"Strong made hand: {evaluation.name}. Value bet unless the board is extremely dangerous."
        if evaluation.category >= 1:
            return f"You currently have {evaluation.name}. Control the pot, then value bet clean rivers."
        return "No made hand yet. Look for straight/flush draws before investing heavily."
    return f"Preflop read: {describe_hole_cards(game.player.hole_cards)}. Position and bet size matter."
