# All-In Academy API

FastAPI backend for the All-In Academy poker trainer.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
fastapi dev app/main.py
```

API docs are available at `http://localhost:8000/docs` while the server is running.

## Endpoints

- `GET /api/health`
- `POST /api/games`
- `GET /api/games/{game_id}`
- `POST /api/games/{game_id}/actions`
- `POST /api/coach`

## Tests

```bash
python -m pytest -q
```
